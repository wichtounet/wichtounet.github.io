package com.wicht.concurrency.s2;

public class ThreadPriority {
	public static void main(String[] args) {
		Thread thread1 = new Thread(new LoopRunnable());
		thread1.setName("Thread 1");
		thread1.setPriority(1);

		Thread thread2 = new Thread(new LoopRunnable());
		thread2.setName("Thread 2");
		thread2.setPriority(5);

		Thread thread3 = new Thread(new LoopRunnable());
		thread3.setName("Thread 3");
		thread3.setPriority(10);

		thread1.start();
		thread2.start();
		thread3.start();
	}

	private static class LoopRunnable implements Runnable {
		@Override
		public void run() {
			for(int i = 0; i < 1000; i++){
				System.out.println("Loop from thread " + Thread.currentThread().getName());
			}
		}
	}
}