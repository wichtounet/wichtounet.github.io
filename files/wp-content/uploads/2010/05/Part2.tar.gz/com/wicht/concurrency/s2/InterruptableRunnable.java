package com.wicht.concurrency.s2;

public class InterruptableRunnable implements Runnable {
	@Override
	public void run() {
		while(!Thread.currentThread().isInterrupted()){
			//Heavy operation
		}
	}
}