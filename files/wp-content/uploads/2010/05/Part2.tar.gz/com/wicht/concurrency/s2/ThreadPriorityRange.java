package com.wicht.concurrency.s2;

public class ThreadPriorityRange {
	public static void main(String[] args) {
		System.out.println("Minimal priority : " + Thread.MIN_PRIORITY);
		System.out.println("Maximal priority : " + Thread.MAX_PRIORITY);
		System.out.println("Norm priority : " + Thread.NORM_PRIORITY);

		System.out.println("Main thread priority : " + Thread.currentThread().getPriority());

		Thread.currentThread().setPriority(7);

		System.out.println("Main thread priority : " + Thread.currentThread().getPriority());

		Thread thread = new Thread();

		System.out.println("Sub thread priority : " + thread.getPriority());
	}
}